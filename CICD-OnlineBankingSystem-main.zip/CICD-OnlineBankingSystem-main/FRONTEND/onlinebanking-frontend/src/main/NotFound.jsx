import React from 'react'

function NotFound() {
  return (
    <div>
      Notfound
    </div>
  )
}

export default NotFound
