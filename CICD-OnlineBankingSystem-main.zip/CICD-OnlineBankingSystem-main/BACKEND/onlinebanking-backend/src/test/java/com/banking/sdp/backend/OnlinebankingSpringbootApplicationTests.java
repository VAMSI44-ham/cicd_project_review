package com.banking.sdp.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlinebankingSpringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
